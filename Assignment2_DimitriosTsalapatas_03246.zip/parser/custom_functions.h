#include <stdlib.h>
#include <stdio.h>

void* my_realloc(void* ptr, size_t size);

void* my_calloc(int nmemb, size_t size);